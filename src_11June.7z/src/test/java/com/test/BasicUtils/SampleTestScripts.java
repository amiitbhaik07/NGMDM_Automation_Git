package com.test.BasicUtils;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class SampleTestScripts 
{
	//_05DQ_TC01_NS_Product_Only__Short_FormID_1
	@Test
	public static void main(String args[]) throws Exception
	{
	BasicUtils basic = new BasicUtils();
	LaunchBrowsers browsers = new LaunchBrowsers();
	WebDriver driver = browsers.launchBrowser("firefox");
	basic.justNavigate(driver, ObjectRepository.salesforce_url);
	basic.typeText(driver, ObjectRepository.sfdc_username_tb, "thaymore@cisco.com.mon");
	basic.typeText(driver, ObjectRepository.sfdc_password_tb, "cisco123");
	basic.click(driver, ObjectRepository.sfdc_login_button);
	if(basic.ifLogic(driver, ObjectRepository.value_111, "Click to Open Sidebar"))
	{
	basic.click(driver, ObjectRepository.sfdc_openSidebar_link);
	}
	basic.click(driver, ObjectRepository.createNew_tabdropdown);
	basic.click(driver, ObjectRepository.sfdc_opportunity_link);
	basic.click(driver, ObjectRepository.sfdc_continue_button);
	basic.typeText(driver, ObjectRepository.value_43, "GOOGLE INC - Corp IT");
	String random = basic.randomNumber(10000, 99999);
	basic.typeText(driver, ObjectRepository.value_44, "05DQ_QualFormPickingAutomation_" + random);
	basic.selectOption(driver, ObjectRepository.value_47, "2 - Qualification");
	basic.selectOption(driver, ObjectRepository.value_3, "Commit");
	basic.selectOption(driver, ObjectRepository.value_4, "1-Tier");
	basic.click(driver, ObjectRepository.value_45);
	basic.typeText(driver, ObjectRepository.value_46, "500");
	basic.selectOption(driver, ObjectRepository.value_5, "8x8");
	basic.click(driver, ObjectRepository.value_6);
	basic.selectOption(driver, ObjectRepository.value_7, "New Installation");
	basic.click(driver, ObjectRepository.value_8);
	basic.pause(30000);
	basic.waitForElementVisible(driver, ObjectRepository.value_112);
	basic.selectOption(driver, ObjectRepository.value_112, "GOOGLE ACCESS US thaymore");
	basic.click(driver, ObjectRepository.value_113);
	basic.click(driver, ObjectRepository.value_50);
	basic.click(driver, ObjectRepository.value_114);
	basic.click_id(driver, ObjectRepository.value_52);
	basic.updateText_id(driver, ObjectRepository.value_52, "100");
	basic.click(driver, ObjectRepository.value_53);
	basic.pause(120000);
	basic.click(driver, ObjectRepository.value_54);
	basic.click(driver, ObjectRepository.value_115);
	basic.selectOption(driver, ObjectRepository.value_116, "Global Price List in US Dollars");
	basic.selectOption(driver, ObjectRepository.value_117, "Cisco");
	basic.selectOption(driver, ObjectRepository.value_118, "Outsource");
	basic.click(driver, ObjectRepository.value_119);
	basic.click(driver, ObjectRepository.value_61);
	basic.waitForElementClickable(driver, ObjectRepository.value_120);
	basic.click(driver, ObjectRepository.value_120);
	basic.pause(10000);
	basic.waitForElementClickable(driver, ObjectRepository.value_121);
	basic.click(driver, ObjectRepository.value_121);
	basic.pause(15000);
	basic.waitForElementClickable(driver, ObjectRepository.value_122);
	basic.click(driver, ObjectRepository.value_122);
	basic.click(driver, ObjectRepository.value_61);
	basic.typeText(driver, ObjectRepository.value_61, "CISCO1921DC/K9");
	basic.click(driver, ObjectRepository.value_62);
	basic.typeText(driver, ObjectRepository.value_62, "1");
	basic.click(driver, ObjectRepository.value_63);
	basic.click(driver, ObjectRepository.value_61);
	basic.click(driver, ObjectRepository.value_71);
	basic.click(driver, ObjectRepository.value_123);
	basic.click(driver, ObjectRepository.value_81);
	basic.clearUpdateText(driver, ObjectRepository.value_82, "20");
	basic.click(driver, ObjectRepository.value_84);
	basic.click(driver, ObjectRepository.value_85);
	basic.click(driver, ObjectRepository.value_86);
	if(basic.ifLogic(driver, ObjectRepository.value_124, "This Quote contains serviceable items without any services attached. Kindly provide a reason in the ‘Please provide reason to not purchase services’ section"))
	{
	basic.click(driver, ObjectRepository.value_125);
	basic.click(driver, ObjectRepository.value_126);
	}
	basic.click(driver, ObjectRepository.value_89);
	basic.click(driver, ObjectRepository.value_90);
	basic.click(driver, ObjectRepository.value_91);
	String DealID = basic.getText(driver, ObjectRepository.value_92);
	basic.typeText(driver, ObjectRepository.value_93, "6");
	basic.click(driver, ObjectRepository.value_94);
	basic.click(driver, ObjectRepository.value_95);
	basic.typeText(driver, ObjectRepository.value_127, "test");
	basic.click(driver, ObjectRepository.value_103);
	basic.click(driver, ObjectRepository.value_104);
	basic.click(driver, ObjectRepository.value_97);
	basic.click(driver, ObjectRepository.value_98);
	basic.click(driver, ObjectRepository.value_128);
	basic.click(driver, ObjectRepository.value_129);
	basic.click(driver, ObjectRepository.value_107);
	basic.click(driver, ObjectRepository.value_108);
	basic.click(driver, ObjectRepository.value_109);
	basic.click(driver, ObjectRepository.value_110);
	basic.pause(30000);
	//basic.identicalMatch(driver, ObjectRepository.value_130, "");
	basic.validateIfPresent(driver, ObjectRepository.value_131);
	basic.validateIfPresent(driver, ObjectRepository.value_132);
	basic.validateIfPresent(driver, ObjectRepository.value_133);
	basic.validateIfPresent(driver, ObjectRepository.value_134);
	basic.validateIfPresent(driver, ObjectRepository.value_135);
	basic.validateIfPresent(driver, ObjectRepository.value_136);
	basic.validateIfPresent(driver, ObjectRepository.value_137);
	basic.validateIfPresent(driver, ObjectRepository.value_138);
	}


	
	

	
	@Test
	public static void _01MyDHPge_TC01_Verify_Data_displayed_by_default_for_DDA_Admin() throws Exception
	{
	BasicUtils basic = new BasicUtils();
	LaunchBrowsers browsers = new LaunchBrowsers();
	WebDriver driver = browsers.launchBrowser("firefox");
	basic.justNavigate(driver, ObjectRepository.ciscoLogin_Url);
	basic.pause(8000);
	basic.typeText(driver, ObjectRepository.username_tb, "meghgupt");
	basic.typeText(driver, ObjectRepository.password_tb, "Prisha$2016");
	basic.click(driver, ObjectRepository.login_button);
	basic.justNavigate(driver, ObjectRepository.value_1);
	basic.typeText(driver, ObjectRepository.proxyId_tb, "josero2");
	basic.click(driver, ObjectRepository.proxyIdSubmit_button);
	basic.validateIfPresent(driver, ObjectRepository.value_2);
	basic.selectOption(driver, ObjectRepository.value_3, "Commit");
	basic.selectOption(driver, ObjectRepository.value_4, "1-Tier");
	basic.selectOption(driver, ObjectRepository.value_5, "8x8");
	basic.click(driver, ObjectRepository.value_6);
	basic.selectOption(driver, ObjectRepository.value_7, "New Installation");
	basic.click(driver, ObjectRepository.value_8);
	basic.pause(30000);
	}
	
	
	@Test
	public static void _03DPr_TC16_Verify_user_is_able_to_add_conditional_rebate_on_RNSD_deal() throws Exception
	{
	BasicUtils basic = new BasicUtils();
	LaunchBrowsers browsers = new LaunchBrowsers();
	WebDriver driver = browsers.launchBrowser("firefox");
	basic.clearBrowserCache(driver);
	basic.justNavigate(driver, ObjectRepository.ciscoLogin_Url);
	basic.pause(8000);
	basic.typeText(driver, ObjectRepository.username_tb, "meghgupt");
	basic.typeText(driver, ObjectRepository.password_tb, "Prisha#2017");
	basic.click(driver, ObjectRepository.login_button);
	basic.justNavigate(driver, ObjectRepository.mdmProxy_Url);
	basic.pause(5000);
	basic.typeText(driver, ObjectRepository.proxyId_tb, "duabhish");
	basic.click(driver, ObjectRepository.proxyIdSubmit_button);
	basic.click(driver, ObjectRepository.advancedSearch_link);
	basic.typeText(driver, ObjectRepository.dealID_textbox, "61000732");
	basic.click(driver, ObjectRepository.advancedSearch_button);
	basic.click(driver, ObjectRepository.dealID_link);
	basic.click(driver, ObjectRepository.value_12);
	basic.click(driver, ObjectRepository.value_13);
	while(basic.isElementPresent(driver, ObjectRepository.value_14))
	{
	basic.click(driver, ObjectRepository.value_14);
	basic.click(driver, ObjectRepository.value_15);
	}
	basic.click(driver, ObjectRepository.value_16);
	basic.click(driver, ObjectRepository.value_16);
	basic.waitForElementClickable(driver, ObjectRepository.value_16);
	basic.click(driver, ObjectRepository.value_17);
	basic.click(driver, ObjectRepository.value_18);
	basic.selectOption(driver, ObjectRepository.value_19, "PRODUCT");
	basic.selectOption(driver, ObjectRepository.value_20, "Conditional Rebate");
	basic.typeText(driver, ObjectRepository.value_21, "desc_03DPr_TC16");
	basic.typeText(driver, ObjectRepository.value_22, "test");
	basic.click(driver, ObjectRepository.value_23);
	basic.validateContains(driver, ObjectRepository.value_24, "Adjustment Value should not be blank and should be numeric up to 2 decimal values");
	basic.clearUpdateText(driver, ObjectRepository.value_22, "16");
	basic.click(driver, ObjectRepository.value_23);
	basic.validateIfPresent(driver, ObjectRepository.value_14);
	basic.click(driver, ObjectRepository.value_16);
	basic.click(driver, ObjectRepository.value_16);
	basic.click(driver, ObjectRepository.value_14);
	basic.click(driver, ObjectRepository.value_15);
	basic.waitForElementClickable(driver, ObjectRepository.value_16);
	basic.click(driver, ObjectRepository.value_16);
	basic.click(driver, ObjectRepository.value_16);
	basic.validateIfNotPresent(driver, ObjectRepository.value_14);
	}
	
	
	@Test
	public static void _03DPr_TC85_Verify_if_FV_assessment_data_is_dispalyed_only_if_FV_is_invoked() throws Exception
	{
	BasicUtils basic = new BasicUtils();
	LaunchBrowsers browsers = new LaunchBrowsers();
	WebDriver driver = browsers.launchBrowser("firefox");
	basic.clearBrowserCache(driver);
	basic.justNavigate(driver, ObjectRepository.ciscoLogin_Url);
	basic.pause(8000);
	basic.typeText(driver, ObjectRepository.username_tb, "meghgupt");
	basic.typeText(driver, ObjectRepository.password_tb, "Prisha$2016");
	basic.click(driver, ObjectRepository.login_button);
	basic.justNavigate(driver, ObjectRepository.mdmProxy_Url);
	basic.typeText(driver, ObjectRepository.proxyId_tb, "ngazaleh");
	basic.click(driver, ObjectRepository.proxyIdSubmit_button);
	basic.click(driver, ObjectRepository.advancedSearch_link);
	basic.typeText(driver, ObjectRepository.dealID_textbox, "64005570");
	basic.click(driver, ObjectRepository.advancedSearch_button);
	basic.click(driver, ObjectRepository.dealID_link);
	basic.click(driver, ObjectRepository.value_25);
	basic.click(driver, ObjectRepository.value_26);
	String price1 = basic.getText(driver, ObjectRepository.value_27);
	String price2 = basic.getText(driver, ObjectRepository.value_28);
	String price3 = basic.getText(driver, ObjectRepository.value_29);
	basic.click(driver, ObjectRepository.value_30);
	basic.click(driver, ObjectRepository.value_31);
	basic.validateContains(driver, ObjectRepository.value_32, price1);
	basic.validateContains(driver, ObjectRepository.value_33, price2);
	basic.validateContains(driver, ObjectRepository.value_34, price3);
	basic.click(driver, ObjectRepository.value_35);
	}




}
