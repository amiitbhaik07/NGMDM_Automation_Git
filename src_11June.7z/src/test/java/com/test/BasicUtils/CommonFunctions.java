package com.test.BasicUtils;

import org.openqa.selenium.WebDriver;

public class CommonFunctions 
{
	//basic.typeText(driver, "", ObjectRepository., "");
	//basic.click(driver, "", ObjectRepository.);
	BasicUtils basic = new BasicUtils();
	
	public void mdmLogin(WebDriver driver, String userName) throws Exception
	{
		
		basic.clearBrowserCache(driver);
		basic.justNavigate(driver, ObjectRepository.ciscoLogin_Url);
		Thread.sleep(8000);
		basic.typeText(driver, ObjectRepository.username_tb, ObjectRepository.mdmProxyUsername);
		basic.typeText(driver, ObjectRepository.password_tb, ObjectRepository.mdmProxyPassword);
		basic.click(driver, ObjectRepository.login_button);
		Thread.sleep(5000);
		basic.typeText(driver, ObjectRepository.proxyId_tb, userName);
		basic.click(driver, ObjectRepository.proxyIdSubmit_button);
	}
	
	public void openDealID(WebDriver driver, String dealId) throws Exception
	{
		advanceSearchDealID(driver, dealId);
		basic.click(driver, ObjectRepository.dealID_link);
	}
	
	public void advanceSearchDealID(WebDriver driver, String dealId) throws Exception
	{
		basic.click(driver, ObjectRepository.advancedSearch_link);
		basic.typeText(driver, ObjectRepository.dealID_textbox, dealId);
		basic.click(driver, ObjectRepository.advancedSearch_button);
	}

}
