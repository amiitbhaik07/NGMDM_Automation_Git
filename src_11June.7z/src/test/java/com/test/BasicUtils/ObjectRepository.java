package com.test.BasicUtils;
public class ObjectRepository 
{
	//Do not delete 
	public static int valueCounterInteger = 139;
	
	//URLs and Logins :
	public static String ciscoLogin_Url = "https://sso-test.cisco.com/autho/forms/CECLogin.html";
	public static String mdmProxy_Url = "http://mdmui-cstg.cloudapps.cisco.com/mdmui/rest/proxyHome";
	public static String mdmProxyUsername = "meghgupt";
	public static String mdmProxyPassword = "Prisha#2017";
	
	public static String duabhish = "duabhish";
	
	
	//Cisco Login Page
	public static String username_tb = "//input[@id='userInput']";
	public static String password_tb = "//input[@id='passwordInput']";
	public static String login_button = "//input[@id='login-button']";
	public static String proxyId_tb = "//input[@id='proxyId']";
	public static String proxyIdSubmit_button = "//button[@type='submit']";
	
	
	//Advanced Search Page
	public static String dealID_textbox = "//*[@kdfid='DealID' and @kdfapp='mdmUI' and @kdfpage='advancedSearch']";
	public static String advancedSearch_button = "//*[@kdfid='AdvSearchBtn' and @kdfapp='mdmUI' and @kdfpage='advancedSearch']";
	
	
	//My Deals Homepage
	public static String advancedSearch_link = "//*[@kdfid='advancedSearch' and @kdfapp='mdmUI' and @kdfpage='myDeals']";
	public static String dealID_link = "//*[starts-with(@kdfid,'deal-link-') and @kdfapp='mdmUI' and @kdfpage='myDeals']";
	
	
	
	//SFDC Pages
	public static String salesforce_url = "https://test.salesforce.com";
	public static String sfdc_username_tb = "//input[@id='username']";
	public static String sfdc_password_tb = "//input[@id='password']";
	public static String sfdc_login_button = "//input[@id='Login']";
	public static String createNew_tabdropdown = "//div[@id='createNew']/div";
	public static String sfdc_opportunity_link = "//div[@id='createNewMenu']/a[6]";
	public static String sfdc_continue_button = "//td[@id='opptyNewOverride:theForm:theBlock:j_id14:bottom']/input";
	public static String sfdc_openSidebar_link = "//span[@id='pinIndicator']";
	

	public static String value_8 = "//input[@name='save']";
	public static String value_6 = "//img[@id='00N30000000gPQx_right_arrow']";
	public static String value_7 = "//select[@id='00N30000002DhSk']";
	public static String value_4 = "//select[@id='00N30000000gPQu']";
	public static String value_5 = "//*[@id='00N30000000gPQx_unselected']";
	public static String value_2 = "//*[@kdfid='dropdown-Active Deals - DEALS DESK' and @kdfapp='mdmUI' and @kdfpage='ngmdmPage']";
	public static String value_3 = "//select[@id='00N30000000gPQs']";
	public static String value_1 = "https://mdmui-wstg.cloudapps.cisco.com/mdmui/rest/proxyHome";
	public static String value_15 = "//*[@kdfid='deleteBtn' and @kdfapp='mdmUI' and @kdfpage='deletepopup']";
	public static String value_26 = "//*[@kdfid='dealPricing' and @kdfapp='mdmUI' and @kdfpage='leftBar']/span";
	public static String value_16 = "//*[@kdfid='topDPSaveAndPublish' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_27 = "//*[@kdfid='fmvRevenue-Product' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_13 = "//*[@kdfid='expandAll' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_24 = "//div[@class='alert alert-danger']/span";
	public static String value_35 = "//*[@kdfid='cancelBtn' and @kdfapp='mdmUI' and @kdfpage='fvAssessment']";
	public static String value_14 = "//*[starts-with(@kdfid,'delete-') and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']/parent::div/parent::td/following-sibling::td[contains(text(),'PRODUCT')]/following-sibling::td[contains(text(),'Conditional Rebate')]/following-sibling::td[*]/span[contains(text(),'desc_03DPr_TC16')]/parent::td/preceding-sibling::td[last()]/div/a[starts-with(@kdfid,'delete-')]";
	public static String value_25 = "//*[@kdfid='DSslideMenu' and @kdfapp='mdmUI' and @kdfpage='ngDealSummary']";
	public static String value_19 = "//label[contains(text(),'Component')]/following-sibling::span/div/div/select";
	public static String value_17 = "//*[@kdfid='EditScenario' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_28 = "//*[@kdfid='fmvRevenue-TSS' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_18 = "//*[@kdfid='addAdjustmentLine' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_29 = "//*[@kdfid='fmvRevenue-Total' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_30 = "//*[@kdfid='utiFV' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_22 = "//*[@kdfid='adjustmentvalue' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_33 = "//td[contains(text(),'SERVICES')]/following-sibling::td[6]";
	public static String value_12 = "//*[starts-with(@kdfid,'compare-') and @kdfapp='mdmUI' and @kdfpage='ngScenarioBrowser']/parent::div/parent::td/following-sibling::td[*]/a[starts-with(@kdfid,'scenarioName-')]";
	public static String value_23 = "//*[@kdfid='AddNewBtn' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_34 = "//td[contains(text(),'Total')]/following-sibling::td[6]";
	public static String value_20 = "//label[contains(text(),'Line Type')]/following::select";
	public static String value_31 = "//*[@kdfid='fvAssessment' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_21 = "//*[@kdfid='description' and @kdfapp='mdmUI' and @kdfpage='ngDealPricing']";
	public static String value_32 = "//td[contains(text(),'PRODUCT')]/following-sibling::td[6]";
	
	public static String value_79 = "//*[@kdfid='icwSaveCiscoTradeinItem' and @kdfapp='Quoting' and @kdfpage='addTradeInItemstab']";
	
	public static String value_70 = "//*[@kdfid='icwButtonModalDone' and @kdfapp='config' and @kdfpage='xaasui']";
	public static String value_73 = "//*[@kdfid='addTradeInItems' and @kdfapp='Quoting' and @kdfpage='itemstab']";
	public static String value_74 = "//*[@kdfid='addCiscoTradeIn' and @kdfapp='Quoting' and @kdfpage='addTradeInItemstab']";
	public static String value_71 = "//div[@class='orderTitle quoteId']/div/h3";
	public static String value_72 = "//*[@kdfid='tabInstallMoreAction kdfpage=' and @kdfapp='Quoting']";
	public static String value_77 = "//div[@class='ac_results']/ul/li/div/strong";
	public static String value_78 = "//*[@kdfid='ciscoQuantity' and @kdfapp='Quoting' and @kdfpage='addTradeInItemstab']";
	public static String value_75 = "//*[@kdfid='ciscoPartNumber' and @kdfapp='Quoting' and @kdfpage='addTradeInItemstab']";
	public static String value_76 = "//*[@kdfid='ciscoProductFamily' and @kdfapp='Quoting' and @kdfpage='addTradeInItemstab']";
	public static String value_68 = "//*[contains(text(),'Configuration Summary')]";
	public static String value_110 = "//label[contains(text(),'Approval Route')]";
	public static String value_69 = "//*[@kdfid='doneConfig' and @kdfapp='config' and @kdfpage='xaasui']";
	public static String value_62 = "//*[@kdfid='searchQty' and @kdfapp='Quoting' and @kdfpage='itemstab']";
	public static String value_63 = "//*[@kdfid='AddSKU' and @kdfapp='Quoting' and @kdfpage='itemstab']";
	public static String value_60 = "//*[@kdfid='createDealBtn' and @kdfapp='Quoting'  and @value='Create Quote']";
	public static String value_61 = "//*[@kdfid='descriptionProduct' and @kdfapp='Quoting' and @kdfpage='itemstab']";
	public static String value_66 = "//*[@kdfid='rdo_NU_STD_MTG' and @kdfapp='config' and @kdfpage='xaasui']/..";
	public static String value_67 = "//*[@kdfid='quantityInput_A-WX-NU-MTGS-25' and @kdfapp='config' and @kdfpage='xaasui']";
	public static String value_64 = "//*[@kdfid='tabDynaSelectoptions' and @kdfapp='Quoting' and @kdfpage='itemstab']/span";
	public static String value_65 = "//*[@kdfid='linkIndent_WEBEX-SAAS-MODEL:CONF_G' and @kdfapp='config' and @kdfpage='xaasui']";
	public static String value_59 = "//*[@kdfid='dealCategory_2' and @kdfapp='Quoting']";
	public static String value_57 = "//*[@kdfid='sourceProfileId_1' and @kdfapp='Quoting']";
	public static String value_58 = "//*[@kdfid='dealCategory' and @kdfapp='Quoting']";
	public static String value_100 = "//*[@kdfid='textarea_2085864384' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_101 = "//*[@kdfid='qualformselect_147' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_102 = "//*[@kdfid='qualformselect_147_2509374741' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_103 = "//*[@kdfid='qualformaddcompetitor' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_104 = "//*[@kdfid='addcompetitormodalcontinue' and @kdfapp='Quoting' and @kdfpage='qualformaddcompetitormodal']";
	public static String value_105 = "//*[@kdfid='qualformselect_2085864217' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_106 = "//*[@kdfid='qualformselect_2085864217_2561827' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_107 = "//*[@kdfid='qualformsaveandcontinue' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_108 = "//*[@kdfid='submitCheck' and @kdfapp='Quoting' and @kdfpage='nsReviewSubmit']/..";
	public static String value_109 = "//*[@kdfid='subDealforQualification' and @kdfapp='Quoting' and @kdfpage='nsReviewSubmit']";
	public static String value_91 = "//input[@value='Continue']";
	public static String value_92 = "//h5[contains(text(),'Deal ID')]/following-sibling::div/h3";
	public static String value_90 = "//*[@kdfid='viewquotequalifysubmit' and @kdfapp='Quoting' and @kdfpage='quoteOverviewPage']";
	public static String value_51 = "//div[@id='myModal2']/div[2]/div/div[3]/button";
	public static String value_95 = "//*[@kdfid='qualformselect_176_47939940' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_52 = "mixPercentageIdValue_0";
	public static String value_96 = "//*[@kdfid='textarea_2085864344' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_93 = "//*[@kdfid='textinput_47939941' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_50 = "//a[@id='techNameToExpand']";
	public static String value_94 = "//*[@kdfid='qualformselect_176' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_55 = "//*[@kdfid='rnsdConfirmation_n' and @kdfapp='Quoting' ]/..";
	public static String value_99 = "//*[@kdfid='textarea_2085864421' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_56 = "//*[@kdfid='sourceProfileId' and @kdfapp='Quoting']";
	public static String value_53 = "//button[@id='saveTech']";
	public static String value_97 = "//*[@kdfid='qualformselect_8' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_54 = "//input[@name='new00N80000002zs9N']";
	public static String value_98 = "//*[@kdfid='qualformselect_8_54' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_48 = "//div[@id='j_id0:j_id17:j_id19:j_id23:j_id32:j_id34']/select";
	public static String value_49 = "//div[@id='technologyApplication']/div/span/button";
	public static String value_46 = "//input[@id='00N30000000gPQn']";
	public static String value_47 = "//select[@id='opp11']";
	public static String value_80 = "//*[@kdfid='icwButtonSaveandContinue' and @kdfapp='Quoting' and @kdfpage='addTradeInItemstab']";
	public static String value_81 = "//*[@kdfid='nonstandardFADisct' and @kdfapp='Quoting' and @kdfpage='discountscreditstab']";
	
	public static String value_84 = "//*[@kdfid='btnCalculate' and @kdfapp='Quoting' and @kdfpage='discountSummaryModal']";
	
	public static String value_85 = "//*[@kdfid='btnSave' and @kdfapp='Quoting' and @kdfpage='discountSummaryModal']";
	public static String value_82 = "//*[@kdfid='productTotDisct' and @kdfapp='Quoting' and @kdfpage='DiscCredits']";
	public static String value_83 = "//*[@kdfid='serviceTotDisct' and @kdfapp='Quoting' and @kdfpage='DiscCredits']";
	public static String value_44 = "//input[@id='opp3']";
	public static String value_88 = "//input[@id='icwModal_confirmCreditAdjustment']";
	public static String value_45 = "//span/span/a";
	public static String value_89 = "//*[@kdfid='submitandreview' and @kdfapp='Quoting' and @kdfpage='reviewandsubmit']";
	
	public static String value_86 = "//*[@kdfid='pdrButtonSaveandContinue' and @kdfapp='Quoting' and @kdfpage='discountscreditstab']";
	public static String value_43 = "//input[@id='opp4']";
	public static String value_87 = "//*[@kdfid='adjustTradeInDiscount' and @kdfapp='Quoting' and @kdfpage='reviewAndSubmit']";
	public static String value_120 = "//a[contains(text(), 'Set preferences for this quote')]";
	public static String value_121 = "//*[@kdfid='selfService' and @kdfapp='Quoting' and @kdfpage='itemstab']/..";
	public static String value_122 = "//div[@id='preferences']/div/a";
	public static String value_123 = "//*[@kdfid='tabIcwButtonSaveandContinue' and @kdfapp='Quoting' and @kdfpage='itemstab']";
	public static String value_124 = "//div[@id='reviewPageErrors']/descendant::span[contains(text(),'This Quote contains serviceable items without any services attached')]";
	public static String value_125 = "//div[@class='select-reason-field']/descendant::a[@title='Select']";
	public static String value_126 = "//*[@kdfid='_RC_001' and @kdfapp='Quoting']";
	public static String value_127 = "//*[@kdfid='textarea_47939905' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_128 = "//*[@kdfid='qualformselect_123' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_129 = "//*[@kdfid='qualformselect_123_175534971' and @kdfapp='Quoting' and @kdfpage='qualform']";
	public static String value_130 = "1";
	public static String value_131 = "//span[@class='icwOrderName' and text()!='']";
	public static String value_132 = "//div[contains(@class,'icwHeaderInfo')]/strong[1][text()!='']";
	public static String value_111 = "//span[@class='zen-assistiveText' and contains(text(),'Click to Open Sidebar')]";
	public static String value_133 = "//div[contains(@class,'icwHeaderInfo')]/strong[2][text()!='']";
	public static String value_112 = "//label[contains(text(),'Forecasting Position')]/../following-sibling::td/descendant::select";
	public static String value_134 = "//div[contains(@class,'icwHeaderInfo')]/strong[3][text()!='']";
	public static String value_113 = "//span[@class='cartlink']/button";
	public static String value_135 = "//div[@class='tabContent']/div[2][@class='rightData' and text()!='']";
	public static String value_114 = "//button[@data-dismiss='modal' and text()='Close']";
	public static String value_136 = "//div[@class='tabContent']/div[4][@class='rightData' and text()!='']";
	public static String value_115 = "//*[@kdfid='rnsdConfirmation_n' and @kdfapp='Quoting' and @kdfpage='CreateQuote']/following-sibling::label";
	public static String value_137 = "//div[@id='approversListWrapper']";
	public static String value_116 = "//*[@kdfid='erpPriceListId' and @kdfapp='Quoting' and @kdfpage='CreateQuote']";
	public static String value_138 = "//*[@kdfid='viewSubmittedQuote' and @kdfapp='Quoting' and @kdfpage='confirmationPage']";
	public static String value_117 = "//*[@kdfid='sourceProfileId' and @kdfapp='Quoting' and @kdfpage='CreateQuote']";
	public static String value_118 = "//*[@kdfid='dealCategory' and @kdfapp='Quoting' and @kdfpage='CreateQuote']";
	public static String value_119 = "//*[@kdfid='createQuote' and @kdfapp='Quoting' and @kdfpage='CreateQuote']";
}
