package com.test.BasicUtils;
public class ObjectRepository2 
{
	//Do not delete 
	public static int valueCounterInteger = 1;
	
	//URLs and Logins :
	public static String ciscoLogin_Url = "https://sso-test.cisco.com/autho/forms/CECLogin.html";
	public static String mdmProxy_Url = "http://mdmui-cstg.cloudapps.cisco.com/mdmui/rest/proxyHome";
	public static String mdmProxyUsername = "meghgupt";
	public static String mdmProxyPassword = "Prisha#2017";
	
	public static String duabhish = "duabhish";
	
	
	//Cisco Login Page
	public static String username_tb = "//input[@id='userInput']";
	public static String password_tb = "//input[@id='passwordInput']";
	public static String login_button = "//input[@id='login-button']";
	public static String proxyId_tb = "//input[@id='proxyId']";
	public static String proxyIdSubmit_button = "//button[@type='submit']";
	
	
	//Advanced Search Page
	public static String dealID_textbox = "//*[@kdfid='DealID' and @kdfapp='mdmUI' and @kdfpage='advancedSearch']";
	public static String advancedSearch_button = "//*[@kdfid='AdvSearchBtn' and @kdfapp='mdmUI' and @kdfpage='advancedSearch']";
	
	
	//My Deals Homepage
	public static String advancedSearch_link = "//*[@kdfid='advancedSearch' and @kdfapp='mdmUI' and @kdfpage='myDeals']";
	public static String dealID_link = "//*[starts-with(@kdfid,'deal-link-') and @kdfapp='mdmUI' and @kdfpage='myDeals']";
	
	

}
