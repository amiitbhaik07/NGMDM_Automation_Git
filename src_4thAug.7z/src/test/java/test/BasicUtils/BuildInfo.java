package test.BasicUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BuildInfo 
{
	/*private static final String timeStamp = new SimpleDateFormat("dd_MMM---hh_mm_ss_a").format(new Date());

	public static String getTimestamp() 
	{
		return timeStamp;
	}*/
	
	public static final String timeStamp = new SimpleDateFormat("dd_MMM---hh_mm_ss_a").format(new Date());
}
